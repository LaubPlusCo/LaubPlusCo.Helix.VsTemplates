
# Local nuget "feed"

Place custom built nugets in this folder to keep them under source control.

*F. ex. Sitecore support fixes etc.*