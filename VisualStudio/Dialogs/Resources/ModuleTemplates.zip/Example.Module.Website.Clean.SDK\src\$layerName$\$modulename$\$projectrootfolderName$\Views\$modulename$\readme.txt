This file is just to include 'Views/$modulename$' automatically in the project. 

Feel free to delete.