namespace $moduleNameSpace$.Rendering.Models
{
    public class ErrorViewModel
    {
        public bool IsInvalidRequest { get; set; }
    }
}
